#!/usr/bin/bash

<<KOMENTARZ

Parametry sed:
-n - na wyjsciu beda wypisywane tylko te linie na których wykonano komendę p (wyświetlanie) lub s (podstawianie) z parametrem p
-e - stosujemy gdy przetwarzamy wiele poleceń lub skryptów
-f - dzięki temu argumentowi wczytujemy komendy z pliku
-v - wyświetla informacje o programie
-t - wyłączenie wyjścia z istotnych komend powłoki, które są wykonywane
-q - likwiduje ostrzeżenia o rezultatach podstawienia
-i - edycja w miejscu, zapisuje zmiany w oryginalnym pliku
-b - zapisywanie kopii zapasowej oryginalnego pliku

Składnia sed:
sed "s/stary/nowy/" plik     - zamiana slowa stary na nowy w zawartości z pliku plik

KOMENTARZ

# Przykład 1 - usuwanie linii
sed -e '1d' -e '2d' -e '7d' ksiazki2.txt

echo ""
echo ""

# Przykład 2 - zastępowanie wyraz1 przez wyraz2 (pierwsze wystąpienie)
sed 's/Proces/Wyrok/' ksiazki2.txt

echo ""
echo ""

# Przykład 3 - zastąpienie wyraz1 przez wyraz2 (globalnie)
sed 's/Proces/Wyrok/g' ksiazki2.txt

echo ""
echo ""

# Przykład 4 - zastępowanie wielu wyrazów - metoda 1
sed 's/Proces/Wyrok/' ksiazki2.txt > ksiazki2m.txt && sed 's/Mały/Duży/' ksiazki2m.txt

echo ""
echo ""

# Przykład 5 - zastępowanie wielu wyrazów - metoda 2
sed 's/Proces/Wyrok/;s/Mały/Duży/' ksiazki2.txt

echo ""
echo ""
