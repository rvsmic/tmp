#!/usr/bin/bash

# Przykład 1 - kropka
echo "1."
echo -e "kot\nplot\npot\npit\npat" | awk "/p.t/"
echo

# Przykład 2 - ^ - początek linii
echo "2."
echo -e "Test\nTenis\nTeraz\nTenor" | awk "/^Ten/"
echo

# Przykład 3 - $ - koniec linii
echo "3."
echo -e "kot\nplot\npot\npit\npat" | awk "/ot$/"
echo

# Przykład 4 - dopasowanie (alternatywa znaków)
echo "4."
echo -e "kot\nlot\npot\npit\npat" | awk "/[pl]ot/"
echo

# Przykład 5 - poza dopasowaniem
echo "5."
echo -e "kot\nlot\npot\npit\npat" | awk "/[^pl]ot/"
echo

# Przykład 6 - alternatywa
echo "6."
echo -e "kot\nlot\npot\npit\npat" | awk "/pot|lot/"
echo

# Przykład 7 - 0 lub 1 wystąpienie
echo "7."
echo -e "sto\nstos" | awk "/stos?/"
echo

# Przykład 8 - 1 lub więcej wystąpień
echo "8."
echo -e "112\n242\n123\n331\n456\n222" | awk "/2+/"
echo

# Przykład 9
echo "9."
echo -e "Nowy traktor\nNowy rower\nNowy samochód\nNowy kombajn"\
 | awk "/Nowy (traktor|kombajn)/"
echo
